TISHA NAIL STORE - LIVE READY PACKAGE

This package is prepared so domain + hosting can be added later.

Included:
- index.html: customer website
- admin.html: admin management panel
- README.txt: original setup notes
- This file: live deployment checklist

IMPORTANT:
The current prototype stores data in browser localStorage. For a true public website,
the next deployment step should connect the booking/design data to an online database
and add secure server-side admin authentication.

When you are ready to put it online:
1. Buy/connect a domain.
2. Choose hosting.
3. Upload the website.
4. Connect the database and secure admin login.
5. Test booking from a customer's phone.
